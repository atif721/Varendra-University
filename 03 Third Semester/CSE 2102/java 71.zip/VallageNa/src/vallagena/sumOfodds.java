package vallagena;

import java.util.Scanner;

public class sumOfodds {
    public static void main(String[] args){
        int size;
        Scanner sc = new Scanner(System.in);
        System.out.print("Input the size of array: ");
        size = sc.nextInt();
        int [] array = new int[size];
        System.out.print("Input the numbers: ");
        for (int i = 0; i< size; i++){
            array[i] = sc.nextInt();
        }
        int sum = 0;
        for (int i = 0; i<size; i++){
            if (array[i] % 2 != 0){
                sum+=array[i];
            }
        }
        System.out.println("Sum of odd numbers are: "+ sum);
    }
}
