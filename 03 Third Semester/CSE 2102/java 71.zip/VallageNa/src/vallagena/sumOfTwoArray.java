package vallagena;

import java.util.Scanner;

public class sumOfTwoArray {
    public static void main(String[] args){
        int size;
        Scanner sc = new Scanner(System.in);
        System.out.print("Input the size of array: ");
        size = sc.nextInt();
        int [] array_one = new int[size];
        int [] array_two = new int[size];
        int [] array_sum = new int[size];

        System.out.print("Input element for first array: ");
        for (int i = 0; i<size; i++){
            array_one[i] = sc.nextInt();
        }

        System.out.print("Input element for second array: ");
        for (int i = 0; i<size; i++){
            array_two[i] = sc.nextInt();
        }

        for (int i = 0; i<size; i++){
            array_sum[i] = array_one[i] + array_two[i];
        }

        System.out.print("Index wise sum array is: ");
        for (int i = 0; i< size; i++){
            System.out.printf("%d ", array_sum[i]);
        }

    }
}
