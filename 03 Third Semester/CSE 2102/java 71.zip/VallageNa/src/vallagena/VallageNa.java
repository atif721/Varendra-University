package vallagena;

public class VallageNa {

    public static void main(String[] args) {
        System.out.println("Veyaa");
    }
    
}
