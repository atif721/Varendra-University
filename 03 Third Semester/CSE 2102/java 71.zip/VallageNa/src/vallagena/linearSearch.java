package vallagena;

import java.util.Scanner;

public class linearSearch {
    public static void main(String[] args){
        int size;
        Scanner sc = new Scanner(System.in);
        System.out.print("Input the size of array: ");
        size = sc.nextInt();
        int [] array = new int[size];


        System.out.print("Input elements for array: ");
        for (int i = 0; i<size; i++){
            array[i] = sc.nextInt();
        }

        System.out.print("Input the search element: ");
        int target = sc.nextInt();

        int location = -1;
        for (int i = 0; i<size; i++){
            if (array[i] == target){
                location = i;
                break;
            }
        }

        if (location == -1){
            System.out.println(target + " not found in array.");
        } else {
            System.out.println(target + " found on array at index " + location);
        }
    }
}
