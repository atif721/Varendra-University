package vallagena;

import java.util.Scanner;

public class secondHighest {
    public static void main(String[] args){
        int size;
        Scanner sc = new Scanner(System.in);
        System.out.print("Input the size of array: ");
        size = sc.nextInt();
        int [] array = new int[size];


        System.out.print("Input element for first array: ");
        for (int i = 0; i<size; i++){
            array[i] = sc.nextInt();
        }
        int temp;
        for (int j = 0; j<size; j++){
            for (int i = 0; i<size - 1; i++){
                if (array[i] < array[i+1]){
                    temp = array[i];
                    array[i] = array[i+1];
                    array[i+1] = temp;
                }
            }
        }

        System.out.println("The second highest element is: " + array[1]);
    }
}
