#include <iostream>
using namespace std;

void printArray(int array[], int size)
{
    for (int i = 0; i < size; i++)
        cout << array[i] << " ";
    cout << endl;
}

void deleteElement(int array[], int *size, int index, int *item)
{
    *item = array[index];
    *size = *size - 1;

    for (int i = index; i < *size; i++)
    {

        array[i] = array[i + 1];
    }
}

int main()
{
    int size, array[100], item, remove_index;
    cout << "Input array size: ";
    cin >> size;
    cout << "Input array elements: ";
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    printArray(array, size);
    cout << "Input the index of element you want to remove: ";
    cin >> remove_index;
    deleteElement(array, &size, remove_index, &item);
    printArray(array, size);
}