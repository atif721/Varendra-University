#include <iostream>
using namespace std;

void printArray(int array[], int size)
{
    for (int i = 0; i < size; i++)
        cout << array[i] << " ";
    cout << endl;
}

int binarySearch(int array[], int size, int item)
{
    int mid = size / 2;
    int location = -1, BEG = 0, END = size - 1;
    while (BEG <= END)
    {
        if (item == array[mid])
        {
            location = mid;
            break;
        }
        else if (item < mid)
        {
            END = mid - 1;
        }
        else
        {
            BEG = mid + 1;
        }
        mid = (BEG + END) / 2;
    }

    return location;
}

int main()
{
    int size, array[100], item;
    cout << "Input array size: ";
    cin >> size;
    cout << "Input array elements: ";
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    printArray(array, size);
    cout << "Search Element: ";
    cin >> item;
    int index = binarySearch(array, size, item);
    if (index != -1)
    {
        cout << "Array index " << index;
    }
    else
    {
        cout << "Item not found." << endl;
    }
}