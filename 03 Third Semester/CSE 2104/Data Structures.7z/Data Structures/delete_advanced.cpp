#include <iostream>
using namespace std;

void printArray(int array[], int size)
{
    for (int i = 0; i < size; i++)
        cout << array[i] << " ";
    cout << endl;
}

void deleteElement(int array[], int *size, int index, int *item)
{
    *item = array[index];
    *size = *size - 1;
    for (int i = index; i < *size; i++)
    {

        array[i] = array[i + 1];
    }
}

int searchElement(int array[], int size, int item)
{
    int index = -1;
    for (int i = 0; i < size; i++)
    {
        if (array[i] == item)
            return i;
    }
    return index;
}

int main()
{
    int size, array[100], item, remove_element;
    cout << "Input array size: ";
    cin >> size;
    cout << "Input array elements: ";
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    printArray(array, size);
    cout << "Input the element you want to remove: ";
    cin >> remove_element;
    int remove_index = searchElement(array, size, remove_element);
    if (remove_index != -1)
    {

        deleteElement(array, &size, remove_index, &item);
        printArray(array, size);
    }
    else
    {
        cout << "Item not found" << endl;
    }
